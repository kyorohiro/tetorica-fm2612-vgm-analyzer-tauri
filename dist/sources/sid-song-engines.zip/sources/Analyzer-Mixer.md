Build from this directory with Emscripten and Rust (wasm32-unknown-unknown):

    python3 build_analyzer_sid_mixer.py --rsid sid-rsid --machine sid8580-machine --out generated/sid-analyzer
